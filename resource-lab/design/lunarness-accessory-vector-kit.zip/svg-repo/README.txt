Accessory Measurement & Closure Kit — Lunarness
12 original line symbols in 64 × 64 viewBoxes; consistent 3-unit rounded strokes.
Files: individual SVG icons, editable component sheet, measurement-method handoff diagram and cover.
Purpose: clear diagrams for accessory designers, stylists and learning materials.
Suggested reuse: relabel endpoint A/B, annotate the documented method, duplicate closure symbols, and distinguish a flat span from a full wrap.
All dimensions in the geometry are arbitrary illustration units, not actual product specifications.
Sources for fitting context:
https://lunarness.com/pages/size-guide
https://lunarness.com/pages/harness-size-calculator
Original assets: CC BY 4.0. See LICENSE.txt.
