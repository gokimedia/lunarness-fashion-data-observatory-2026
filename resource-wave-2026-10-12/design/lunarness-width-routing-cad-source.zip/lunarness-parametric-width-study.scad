// Original AI-assisted Lunarness teaching geometry. Units: mm.
// No physical print, strength or wearable-use validation.
// Select width gauge with part="gauge"; frame with part="frame".
part="gauge"; nominal_width=30; clearance=0.4; border=4; thickness=3;
slot_width=nominal_width+clearance;
module gauge() {
  linear_extrude(height=thickness) difference() {
    square([slot_width+2*border,12+2*border],center=true);
    square([slot_width,12],center=true);
  }
}
module frame() {
  linear_extrude(height=thickness) difference() {
    square([slot_width+2*border,28],center=true);
    translate([0,-6.5]) square([slot_width,7],center=true);
    translate([0, 6.5]) square([slot_width,7],center=true);
  }
}
if(part=="frame") frame(); else gauge();
