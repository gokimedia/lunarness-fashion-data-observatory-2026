Lunarness Open Design Study 02 - width and fitting resources
Original AI-assisted procedural CAD and drafting artwork, 2026-10-12.
These are new resources, not mirrors of the previous accessory vector symbol kit.

Measurement sources:
https://lunarness.com/pages/size-guide
https://lunarness.com/pages/harness-size-calculator

Paper kit:
- Use the A4 or Letter PDF matching the printer paper.
- Print actual size / 100 percent. Turn off Fit to page.
- Measure the reference line: it must be 100 mm before cutting.
- Cut the solid outlines. The five widths are material swatches, not body sizes.
- Record body measurements independently using the source guide.
- No physical print test or comfort/strength validation has been performed.

CAD kit:
- Five independent one-slot width coupons: nominal widths 20,25,30,35,40 mm.
- Every coupon includes a total authored slot clearance of 0.4 mm.
- One double-slot 30 mm routing teaching frame.
- Units: millimetres. STL has no standard unit field: import as mm.
- STL and OBJ are exact exports of the procedural mesh source.
- OpenSCAD file provides editable width, clearance, border, thickness and part mode.
- Start any print experiment flat on the bed and measure the result.
- The selected clearance is a design parameter, not a validated tolerance recommendation.
- No physical test print, load rating, body fit or digital twin claim.
- Do not use the teaching frame as a load-bearing wearable closure.

Portfolio:
- Images are software renders of actual authored geometry.
- Lifted ribbon stages are an explanatory illustration, not a print-tested routing assembly.
- No fake photographs or third-party assets are included.

Rights:
Original teaching PDF/SVG layouts and exported STL/OBJ geometry: CC BY 4.0.
https://creativecommons.org/licenses/by/4.0/
Editable OpenSCAD software source: MIT (see LICENSE-MIT.txt in the CAD bundle).
Suggested attribution: Lunarness Open Design Study 02, 2026-10-12,
original AI-assisted procedural design, created for Lunarness.
State any changes and retain the relevant license notice and source links.
The grant covers only the original resource files and rights held in them.
Brand names, trademarks, source website content, product photographs and
product descriptions are excluded from this resource license.
No third-party artwork or private account metadata is included.
